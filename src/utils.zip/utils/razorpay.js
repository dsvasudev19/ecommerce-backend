const Razorpay = require('razorpay');


var instance = new Razorpay({
    key_id: 'rzp_test_5JV9Flqb9kUEIU',
    key_secret: '5SxQcTapOiBg7hFlC5TaotNs',
});

module.exports=instance;

